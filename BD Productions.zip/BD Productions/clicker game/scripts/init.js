(function () {
    console.log("BAD! NO FREE CLICKS, STOP RIGHT THERE!");
})();