
//Varibales
let clicks = 0;
let cpc = 1;
let cursorP = 10;
let uP = 50;
let tR = 1000000;
let gR = 500000000;
let developmentMode = false;
let cps = 0;
let delay = 0;
let coins = 0;
let selling = 1000000000;
let mut = 1;
let goo = 10;
let code = document.getElementById("coder");
let book = 100;
let op = 500;
let moe = 800;
let kore = 1000;
let key = 0;
let cgb = 1500;
let end = 3000;
let pay = 0;
let stock = 10;
let bock = 10;
let fock = 1;
let nock = 3;
let yock = 3;


//END (v)

//No Nan



//END (nnan)

if(developmentMode === true) {
    clicks = 10000000000000;
}

function startgame() {
    document.getElementById("sBut").disabled = true;
    document.getElementById("sBut").hidden = true;
    document.getElementById("aBut").disabled = false;
    document.getElementById("mBut").disabled = false;
    document.getElementById("dBut").disabled = false;
    document.getElementById("stBut").disabled = false;
    document.getElementById("screen").hidden = true;
    document.getElementById("trBut").disabled = false;
    document.getElementById("gBut").disabled = false;
    document.getElementById("penice").hidden = false;
    document.getElementById("footy").hidden = false;
}

function add() {
   clicks += cpc;
   document.getElementById("clickcount").innerHTML = 'Clicks: ' + clicks;
};


function sub() {
    if(clicks >= cursorP) {
        pay+=1;
        clicks-=cursorP;
        cursorP = Math.round(cursorP * 1.1);
        cps += 1;
        document.getElementById("clickcount").innerHTML = 'Clicks: ' + clicks;
        document.getElementById("cursorPriceText").innerHTML = 'Cursor Price: ' + cursorP;
        document.getElementById("cps-text").innerHTML = 'CPS: ' + cps;
        setInterval(function () {Element.innerHTML = add()}, 1000);
    } else {
        alert("Not Enough Clicks!")
    }
    };

    function dbl() {
        if(clicks >= uP) {
            pay+=1;
            clicks-=uP;
            uP = Math.round(uP * 1.1);
            cpc += 1;
            cps += 1;
            document.getElementById("clickcount").innerHTML = 'Clicks: ' + clicks;
            document.getElementById("upText").innerHTML = 'Upgrade Price: ' + uP;
            document.getElementById("cpc-text").innerHTML = 'CPC: ' + cpc;
            document.getElementById("cps-text").innerHTML = 'CPS: ' + cps;
        } else {
            alert("Not Enough Clicks!")
        }
    }

    function trp() {
        if(clicks >= tR) {
            pay+=1;
            clicks-=tR;
            tR = Math.round(tR * 1.1);
            cpc += 100;
            cps += 100;
            document.getElementById("clickcount").innerHTML = 'Clicks: ' + clicks;
            document.getElementById("facText").innerHTML = 'BIG UPGRADE Price: ' + tR;
            document.getElementById("cpc-text").innerHTML = 'CPC: ' + cpc;
            document.getElementById("cps-text").innerHTML = 'CPS: ' + cps;
        } else {
            alert("Not Enough Clicks!")
        }
    }

    function god() {
        if(clicks >= gR) {
            pay+=1;
            clicks-=gR;
            gR = Math.round(gR * 1.2);
            cpc += 1000;
            cps += 1000;
            document.getElementById("clickcount").innerHTML = 'Clicks: ' + clicks;
            document.getElementById("godText").innerHTML = 'GODLY MOUSE Price: ' + gR;
            document.getElementById("cpc-text").innerHTML = 'CPC: ' + cpc;
            document.getElementById("cps-text").innerHTML = 'CPS: ' + cps;
        } else {
            alert("Not Enough Clicks!")
        }
    }

    function sold() {
        if(clicks >= selling) {
            clicks-=selling;
            coins += 1;
            document.getElementById("coincount").innerHTML = 'Coins: ' + coins;
            document.getElementById("coincounter").innerHTML = 'Coins: ' + coins;
            document.getElementById("clickcount").innerHTML = 'Clicks: ' + clicks;
        } else {
            alert("Not Enough Clicks!")
        }
    }

    function hopp() {
        if(coins >= mut) {
            if(stock >= 1) {
                stock-=1;
                pay+=1;
                coins-=mut;
                cps *= 2;
                cpc *= 2;
                document.getElementById("coincount").innerHTML = 'Coins: ' + coins;
                document.getElementById("coincounter").innerHTML = 'Coins: ' + coins;
                document.getElementById("cpc-text").innerHTML = 'CPC: ' + cpc;
                document.getElementById("cps-text").innerHTML = 'CPS: ' + cps;
            } else {
                alert("OUT OF STOCK!")
            }
            
        } else {
            alert("Not Enough Coins!")
        }
    }

    function gas() {
        if(coins >= goo) {
            if(bock >= 1) {
                bock-=1;
                pay+=1;
                coins-=goo;
                cps+=500;
                document.getElementById("coincount").innerHTML = 'Coins: ' + coins;
                document.getElementById("coincounter").innerHTML = 'Coins: ' + coins;
                document.getElementById("cps-text").innerHTML = 'CPS: ' + cps;
                setInterval(function () {Element.innerHTML = add()}, 1);
            } else {
                alert("OUT OF STOCK!")
            }
            
        } else {
            alert("Not Enough Coins!")
        }
    }

    function bage() {
        if(coins >= book) {
            if(fock >= 1) {
                fock-=1;
                coins-=book;
                document.getElementById("baggie").hidden = false;
                alert(":> !?");
                document.getElementById("coincount").innerHTML = 'Coins: ' + coins;
                document.getElementById("coincounter").innerHTML = 'Coins: ' + coins;
            } else {
                alert("OUT OF STOCK!")
            }
            
        } else {
            alert("Not Enough Coins!")
        }
        
    }

    function omg() {
        if(coins >= op) {
            if(nock >= 1) {
                nock-=1;
                pay+=1;
                coins-=op;
                cps *= 10;
                cpc *=10;
                document.getElementById("coincount").innerHTML = 'Coins: ' + coins;
                document.getElementById("coincounter").innerHTML = 'Coins: ' + coins;
                document.getElementById("cpc-text").innerHTML = 'CPC: ' + cpc;
                document.getElementById("cps-text").innerHTML = 'CPS: ' + cps;
            } else {
                alert("OUT OF STOCK!")
            }
            
        } else {
            alert("Not Enough Coins!")
        }
    };

    function mono() {
        if(coins >= moe) {
            if(yock >= 1) {
                yock-=1;
                pay+=1;
                coins-=moe;
                cps+=50000;
                document.getElementById("coincount").innerHTML = 'Coins: ' + coins;
                document.getElementById("coincounter").innerHTML = 'Coins: ' + coins;
                document.getElementById("cps-text").innerHTML = 'CPS: ' + cps;
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
                setInterval(function () {Element.innerHTML = add()}, 0.000001);
            } else {
                alert("OUT OF STOCK!")
            }
            
        } else {
            alert("Not Enough Coins!")
        }
    };

    function kory() {
        if(coins >= kore) {
            key+=1;
            coins-=kore;
            document.getElementById("kens").disabled = true;
            document.getElementById("kronk").hidden = false;
            document.getElementById("coincount").innerHTML = 'Coins: ' + coins;
            document.getElementById("coincounter").innerHTML = 'Coins: ' + coins;
            alert("Where Could This Key Go?");
        } else {
            alert("Not Enough Coins!")
        }
    }

    let fpop = document.getElementById("fpop");

    function mamama() {
        if(key >= 1) {
            fpop.classList.add('open-fp');
        } else {
            alert("You Need A Key...");
        }
    }

    function adios() {
        fpop.classList.remove('open-fp');
    }

    function cgre() {
        if(coins >= cgb) {
            pay+=1;
            coins-=cgb;
            cps+=100000;
            document.getElementById("coincount").innerHTML = 'Coins: ' + coins;
            document.getElementById("coincounter").innerHTML = 'Coins: ' + coins;
            document.getElementById("cps-text").innerHTML = 'CPS: ' + cps;
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
            setInterval(function () {Element.innerHTML = add()}, 0.000001);
        } else {
            alert("Not Enough Coins!")
        }
    }

    function ender() {
        if(coins >= end) {
            coins-=end;
            alert("A Wild Button Has Appeared!?");
            document.getElementById("ballsack").hidden = false;
        } else {
            alert("Not Enough Coins!")
        }
    }

    function lick() {
        document.getElementById("rawrer").hidden = false;
        changeColor('#000');
        document.getElementById("footy").hidden = true;
        document.getElementById("locker").hidden = true;
        document.getElementById("penice").hidden = true;
        document.getElementById("kronk").hidden = true;
        document.getElementById("gah").innerHTML = 'Clicks: ' + clicks;
        if(pay >= 1) {
            if(clicks >= Infinity) {
                document.getElementById("cha").hidden = false;
                document.getElementById("rah").hidden = true;
                document.getElementById("kah").hidden = true;
                document.getElementById("murder").hidden = false;
                document.getElementById("redrum").hidden = true;
                alert("Corrupted ENDING");
            } else {
                document.getElementById("kah").hidden = false;
                document.getElementById("rah").hidden = true;
                alert("It's Just Business... ENDING");
            }
            
        } else {
            document.getElementById("kah").hidden = true;
            document.getElementById("rah").hidden = false;
            alert("Correct ENDING");
        }
        
    }

    function helpyou() {
        document.getElementById("conman").hidden = false;
        document.getElementById("cha").hidden = true;
        document.getElementById("murder").hidden = true;
        document.getElementById("redrum").hidden = false;
    }

    function helpme() {
        if(clicks >= Infinity) {
            document.getElementById("kah").hidden = true;
            document.getElementById("redrum").hidden = true;
            document.getElementById("mah").hidden = true;
            document.getElementById("yah").hidden = false;
            document.getElementById("nah").hidden = false;
            document.getElementById("bah").hidden = false;
            document.getElementById("fah").hidden = false;
            document.getElementById("lah").hidden = false;
            document.getElementById("pah").hidden = false;
            document.getElementById("penice").hidden = true;
            document.getElementById("gah").hidden = false;
            document.getElementById("rah").hidden = true;
            document.getElementById("cha").hidden = true;
        } else {
            document.getElementById("kah").hidden = true;
            document.getElementById("redrum").hidden = true;
            document.getElementById("mah").hidden = false;
            document.getElementById("yah").hidden = false;
            document.getElementById("nah").hidden = false;
            document.getElementById("bah").hidden = false;
            document.getElementById("fah").hidden = false;
            document.getElementById("lah").hidden = false;
            document.getElementById("pah").hidden = false;
            document.getElementById("penice").hidden = false;
            document.getElementById("gah").hidden = false;
            document.getElementById("rah").hidden = true;
            document.getElementById("cha").hidden = true;
        }
        
    }

    let popup = document.getElementById("popup");

    function openPopup() {
        popup.classList.add('open-popup');
    }

    function closePopup() {
        popup.classList.remove('open-popup');
    }

    let bpop = document.getElementById("bpop");

    function openBp() {
        bpop.classList.add('open-bp');
    }

    function closeBp() {
        bpop.classList.remove('open-bp');
    }

    let ipop = document.getElementById("ipop");

    function openIp() {
        ipop.classList.add('open-ip');
    }

    function closeIp() {
        ipop.classList.remove('open-ip');
    }

    let spop = document.getElementById("spop");

    function sale() {
        spop.classList.add('open-sp');
    }

    function closeSp() {
        spop.classList.remove('open-sp');
    }

    function changeColor(color) {
        document.body.style.background = color;
    }

    function changeR() {
        changeColor('red');
    }

    function changeG() {
        changeColor('#333');
    }

    function changeW() {
        changeColor('#fff');
    }

    function changeP() {
        changeColor('purple');
    }

    function turnOff() {
        document.getElementById("cps-text").hidden = true;
        document.getElementById("cpc-text").hidden = true;
        document.getElementById("turnoff").disabled = true;
        document.getElementById("turnon").disabled = false;
    }

    function turnOn() {
        document.getElementById("cps-text").hidden = false;
        document.getElementById("cpc-text").hidden = false;
        document.getElementById("turnoff").disabled = false;
        document.getElementById("turnon").disabled = true;
    }



    const theme = new Audio(audio.loop=true);
    audio.src = "music/gametheme.mp3";

    function updatecount() {
        if(Cookies.get("clicks") != null && Cookies.get("clicks") != "undefined"){
            let clicker1 = JSON.parse(Cookies.get("clicks"))
        }
        if(delay >= 40) {
            delay++;
            Cookies.set("clicks",JSON.stringify(clicks), {expires: 100000});
            delay = 0;
        }
    }

    if(clicks > 100000) {
        coin += 1;
    };

    //11:09 On Video