const theme = new Audio(audio.loop=true);
audio.src = "music/menu.mp3";