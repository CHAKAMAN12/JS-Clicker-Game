
//Varibales
let clicks = 0;


//END (v)

//No Nan



//END (nnan)



function add() {
   clicks++;
   document.getElementById("clickcount").innerHTML = 'Clicks: ' + clicks;
};

function sub() {
    clicks-=10;
    document.getElementById("clickcount").innerHTML = 'Clicks: ' - clicks;
    setInterval(function () {Element.innerHTML = add()}, 1000);
};